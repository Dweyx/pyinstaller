Please refer to the [Development
Guide](https://pyinstaller.readthedocs.io/en/latest/development/).
