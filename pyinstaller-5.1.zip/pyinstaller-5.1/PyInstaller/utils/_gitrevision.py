#
# The content of this file will be filled in with meaningful data when creating an archive using `git archive` or by
# downloading an archive from github, e.g., from github.com/.../archive/develop.zip
#
rev = "4b9fd01d7d"  # abbreviated commit hash
commit = "4b9fd01d7dc5a0aae3ba7c100437547915464f0e"  # commit hash
date = "2022-05-17 19:29:29 +0100"  # commit date
author = "Brénainn Woodsend <bwoodsend@gmail.com>"
ref_names = "tag: v5.1"  # incl. current branch
commit_message = """Release 5.1.
"""
